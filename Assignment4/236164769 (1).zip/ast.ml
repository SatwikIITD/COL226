type term =
  | Var of string
  | Const of string
  | Function of string * term list
  | Atom of atomic_formula

and atomic_formula =
  | Predicate of string * term list

type clause =
  | Query of string * atomic_formula list
  | Fact of atomic_formula
  | Rule of atomic_formula * atomic_formula list

type program = Program of clause list

let rec term_string = function
  | Var v -> Printf.sprintf "Var(%s)" v
  | Const c -> Printf.sprintf "Const(%s)" c
  | Function (f, terms) -> Printf.sprintf "Function(%s, [%s])" f (String.concat "; " (List.map term_string terms))
  | Atom a -> atomic_formula_string a

and atomic_formula_string (Predicate (p, terms)) =
  Printf.sprintf "Predicate(%s, [%s])" p (String.concat "; " (List.map term_string terms))

let rec clause_string = function
  | Query (q, formulas) -> Printf.sprintf "Query(%s, [%s])" q (String.concat "; " (List.map atomic_formula_string formulas))
  | Fact f -> Printf.sprintf "Fact(%s)" (atomic_formula_string f)
  | Rule (head, body) -> Printf.sprintf "Rule(%s, [%s])" (atomic_formula_string head) (String.concat "; " (List.map atomic_formula_string body))

let program_string (Program clauses) =
  Printf.sprintf "Program(\n%s\n)" (String.concat ";\n" (List.map clause_string clauses))
