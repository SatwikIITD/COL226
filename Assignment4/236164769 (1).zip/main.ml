open Ast

let print_ast input = 
  let lexbuf = Lexing.from_string input in 
  try 
    let ast = A4p.program A4l.token lexbuf in  
    print_endline (program_string ast) 
  with   
    | Parsing.Parse_error ->
        let curr = lexbuf.Lexing.lex_curr_p in
        let line = curr.Lexing.pos_lnum in
        let cnum = curr.Lexing.pos_cnum - curr.Lexing.pos_bol in
        Printf.eprintf "Parser error at line %d, column %d\n" line cnum;
        exit 1

let () =
  let input = "parent(a,b) :- son(brother(a,sister(e,f)),add(1,4)) , child(and(1,2),4) , is_child(true,false). ?- brother(a,c). " in
  print_ast input