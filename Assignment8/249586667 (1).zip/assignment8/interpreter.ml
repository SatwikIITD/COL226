open Mgu  
open A4l
open A4p

let rec subs_formula subst (formula: atomic_formula) =
  match formula with
  | Predicate (p, args) ->
      Printf.printf "Applying substitutions to Predicate(%s)\n" p;
      Predicate (p, List.map (subs subst) args)
  | Function(head, body) ->    
      let substituted_args = List.map (subs subst) body in 
      Printf.printf "Applying substitution to Function whyyy(%s)\n" head;
      Function(head, substituted_args)
  | Bool2 b ->
      Printf.printf "No substitutions apply to Bool2(%b)\n" b;
      Bool2 b

(* Function to apply substitutions to a list of atomic formulas *)
and subs_formula_list subs = function
  | [] -> 
      Printf.printf "End of formula list.\n";
      []
  | formula::tail ->
      Printf.printf "Processing next formula in list.\n";
      let applied = subs_formula subs formula in
      Printf.printf "Substitution result: %s\n" (string_of_atomic_formula applied);
      applied :: subs_formula_list subs tail

(* Placeholder function to convert atomic formula to string for debugging *)
and string_of_atomic_formula = function
  | Predicate (p, args) -> Printf.sprintf "Predicate(%s, [%s])" p (String.concat ", " (List.map string_of_term args))
  | Function (p, args) -> Printf.sprintf "Function(%s, [%s])" p (String.concat ", " (List.map string_of_term args))
  | Bool2 b -> Printf.sprintf "Bool(%b)" b
;;

let eval_and_convert sub formula =
  match formula with
  | Function(a, b) ->
      Printf.printf "Applying substitutions to Function: %s\n" a;
      let substituted_args = List.map (subs sub) b in  (* Apply substitutions to arguments *)
      Printf.printf "Substituted args for %s: [%s]\n" a (String.concat "; " (List.map string_of_term substituted_args));
      let ans = eval2 (Function(a, substituted_args)) in  (* Evaluate the function and ensure it returns Bool2 *)
      Printf.printf "Evaluation result of %s: %s\n" a (string_of_atomic_formula ans);
      ans
  | _ ->
      Printf.printf "Handling non-function atomic formula.\n";
      subs_formula sub formula
;;

let rec solve program goals =
  match goals with
  | [] -> 
      Printf.printf "All goals resolved; returning identity substitution.\n";
      Some [id_sub]  (* No more goals, return the identity substitution as success *)
  | (Bool2 true)::rem -> solve program rem
  | (Bool2 false)::_ -> None 
  | goal::rem ->
      Printf.printf "Current goal: %s\n" (string_of_atomic_formula goal);
      let process_clause acc clause =
        match clause with
        | Fact fact ->
            Printf.printf "Matching goal with fact: %s\n" (string_of_atomic_formula fact);
            (match mgu (Atom goal) (Atom fact) with
            | None -> 
                Printf.printf "No unification possible with fact.\n";
                acc
            | Some subst ->
                Printf.printf "Unification successful with fact, applying substitution.\n";
                let goal2 = List.map (fun formula -> eval_and_convert subst formula) rem in
                match solve program goal2 with
                | None -> 
                    Printf.printf "Failed to solve remaining goals after applying fact.\n";
                    acc
                | Some sub2 -> 
                    Printf.printf "Successfully solved remaining goals after fact, composing substitutions.\n";
                    acc @ List.map (compose_subst subst) sub2)
        | Rule (rule_head, body) ->
            Printf.printf "Matching goal with rule head: %s\n" (string_of_atomic_formula rule_head);
            (match mgu (Atom goal) (Atom rule_head) with
            | None -> 
                Printf.printf "No unification possible with rule head.\n";
                acc
            | Some sub ->
                Printf.printf "Unification successful with rule head, processing rule body.\n";
                let body2 = List.map (fun formula -> eval_and_convert sub formula) body in
                Printf.printf "Substitution applied on body\n";
                let goal2 = List.map (fun formula -> eval_and_convert sub formula) rem in
                match solve program (body2 @ goal2) with
                | None -> 
                    Printf.printf "Failed to solve after applying rule.\n";
                    acc
                | Some sub2 -> 
                    Printf.printf "Successfully solved after applying rule, composing substitutions.\n";
                    acc @ List.map (compose_subst sub) sub2)
        | _ -> acc
      in
      Printf.printf "Processing program clauses.\n";
      let sub_final = List.fold_left process_clause [] program in
      if sub_final = [] then 
        (Printf.printf "No successful substitutions found, query failed.\n"; None)
      else
        (Printf.printf "Found successful substitutions.\n"; Some sub_final)

(* Function to convert terms to strings for debugging, with recursive handling of Atom types *)
and string_of_term = function
  | Var v -> Printf.sprintf "Var(%s)" v
  | Const c -> Printf.sprintf "Const(%s)" c
  | Function (f, args) ->
      Printf.sprintf "Function(%s, [%s])" f (String.concat ", " (List.map string_of_term args))
  | Atom a -> string_of_atomic_formula a  (* Recursively handle atomic formulas *)
  | Id id -> Printf.sprintf "Id(%s)" id
  | Bool b -> Printf.sprintf "Bool(%b)" b

(* Function to convert atomic formulas to strings, recursing through potential nested structures *)
and string_of_atomic_formula = function
  | Predicate (p, args) ->
      Printf.sprintf "Predicate(%s, [%s])" p (String.concat ", " (List.map string_of_term args))
  | Function (f, args) ->
      Printf.sprintf "Function(%s, [%s])" f (String.concat ", " (List.map string_of_term args))
  | Bool2 b -> Printf.sprintf "Bool2(%b)" b
;;

(* Interpret function that processes the input and executes the parsed program *)
let rec interpret input =
  let lexbuf = Lexing.from_string input in
  let Program clauses = A4p.program A4l.token lexbuf in
  Printf.printf "Parsed Program:\n%s\n" (string_of_clauses clauses);  (* Print parsed clauses for debugging *)
  clauses |> List.iter (function
    | Query(_, goals) ->
        begin match solve clauses goals with
        | Some sub_final ->
            List.iter (fun subs ->
                List.iter (fun (var, term) ->
                    Printf.printf "%s -> %s\n" var (string_of_term term)
                ) subs
            ) sub_final
        | None -> 
            Printf.printf "Query failed.\n"
        end
    | Fact _ -> ()  (* Ignore non-query clauses *)
    | Rule(_, _) -> ())  (* Ignore non-query clauses *)

(* Convert a clause to a string for debugging *)
and string_of_clause = function
  | Query(_, goals) -> 
    "Query with goals: " ^ (String.concat ", " (List.map string_of_atomic_formula goals))
  | Fact fact ->
    "Fact: " ^ (string_of_atomic_formula fact)
  | Rule(head, body) ->
    "Rule: " ^ (string_of_atomic_formula head) ^ " :- " ^ (String.concat ", " (List.map string_of_atomic_formula body))

(* Convert a list of clauses to a string *)
and string_of_clauses clauses =
  String.concat "\n" (List.map string_of_clause clauses)

(* Convert term to string for debugging *)
and string_of_term = function
  | Var v -> Printf.sprintf "Var(%s)" v
  | Const c -> Printf.sprintf "Const(%s)" c
  | Function (f, args) -> Printf.sprintf "Function(%s, [%s])" f (String.concat ", " (List.map string_of_term args))
  | Atom a -> string_of_atomic_formula a
  | Id id -> Printf.sprintf "Id(%s)" id
  | Bool b -> Printf.sprintf "Bool(%b)" b
;;


(* Convert atomic_formula to string for debugging
let string_of_atomic_formula = function
  | Predicate (p, terms) -> Printf.sprintf "%s(%s)" p (String.concat ", " (List.map string_of_term terms))

(* Convert a clause to a string for debugging *)
and string_of_clause = function
  | Query(_, goals) -> 
    "Query with goals: " ^ (String.concat ", " (List.map string_of_atomic_formula goals))
  | Fact fact ->
    "Fact: " ^ (string_of_atomic_formula fact)
  | Rule(head, body) ->
    "Rule: " ^ (string_of_atomic_formula head) ^ " :- " ^ (String.concat ", " (List.map string_of_atomic_formula body))

(* Convert a list of clauses to a string *)
and string_of_clauses clauses =
  String.concat "\n" (List.map string_of_clause clauses)

(* Convert substitution list to string for debugging *)
and string_of_substitutions subs =
  String.concat ", " (List.map (fun (var, term) -> Printf.sprintf "%s -> %s" var (string_of_term term)) subs)
;; *)

(* Example usage
let () =
  let input = "parent(alice,bob). parent(bob,charlie). grandparent(X,Y) :- parent(X,Z) , parent(Z,Y). ?- grandparent(alice,Who). " in
  interpret input
;; *)

(* let () =
  let input = "parent(alice,bob). parent(alice,charlie). ?- parent(alice,X). " in
  interpret input
;; *)

(* let input = "p(a,b). p(b,c). p(a,d). p(d,e). g(X,Y) :- p(X,Z) , p(Z,Y). ?- g(a,W). " in
  interpret input *)

(* let input = "salary(a,500). years(a,15). qualifies(Employee) :- years(Employee,Years) , greater(Years,10). ?- qualifies(a). " in
interpret input
   *)

let input = "salary(a,500). years(a,15). qualifies(Employee) :- years(Employee,Years) , lesser(Years,10). ?- qualifies(a). " in
interpret input

(* Program(
  Fact(Predicate(parent, [Var(alice); Var(bob)]));
  Fact(Predicate(parent, [Var(bob); Var(charlie)]));
  Rule(Predicate(grandparent, [Var(X); Var(Y)]), [Predicate(parent, [Var(X); Var(Z)]); Predicate(parent, [Var(Z); Var(Y)])]);
  Query(query, [Predicate(grandparent, [Var(alice); Var(Who)])])
  ) *)

  (* A(2).
  B(3).
  C(X) :- A(X),B(X).
  ?- C(X) *)