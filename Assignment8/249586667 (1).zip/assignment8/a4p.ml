type token =
  | FUNCTION of (string)
  | CONSTANT of (string)
  | IDENTIFIER of (string)
  | VARIABLE of (string)
  | IF
  | THEN
  | ELSE
  | IMPLIES
  | QUERY
  | TRUE
  | FALSE
  | LPAREN
  | RPAREN
  | COMMA
  | DOT
  | WHITESPACE
  | EOF

open Parsing;;
let _ = parse_error;;
# 2 "a4p.mly"
open Mgu
# 25 "a4p.ml"
let yytransl_const = [|
  261 (* IF *);
  262 (* THEN *);
  263 (* ELSE *);
  264 (* IMPLIES *);
  265 (* QUERY *);
  266 (* TRUE *);
  267 (* FALSE *);
  268 (* LPAREN *);
  269 (* RPAREN *);
  270 (* COMMA *);
  271 (* DOT *);
  272 (* WHITESPACE *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  257 (* FUNCTION *);
  258 (* CONSTANT *);
  259 (* IDENTIFIER *);
  260 (* VARIABLE *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\002\000\003\000\003\000\003\000\005\000\006\000\
\004\000\008\000\008\000\007\000\007\000\007\000\007\000\009\000\
\009\000\010\000\010\000\010\000\010\000\010\000\000\000"

let yylen = "\002\000\
\002\000\003\000\000\000\004\000\002\000\002\000\001\000\005\000\
\001\000\001\000\005\000\004\000\004\000\001\000\001\000\001\000\
\003\000\001\000\001\000\001\000\004\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\000\000\014\000\015\000\023\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\001\000\000\000\005\000\006\000\000\000\000\000\020\000\000\000\
\019\000\022\000\000\000\000\000\000\000\000\000\000\000\009\000\
\002\000\000\000\000\000\013\000\000\000\012\000\004\000\000\000\
\000\000\000\000\017\000\000\000\008\000\013\000\000\000\011\000"

let yydgoto = "\002\000\
\008\000\009\000\010\000\030\000\011\000\012\000\026\000\032\000\
\027\000\028\000"

let yysindex = "\007\000\
\015\255\000\000\253\254\254\254\003\255\000\000\000\000\000\000\
\013\000\011\255\255\254\013\255\016\255\001\255\001\255\019\255\
\000\000\015\255\000\000\000\000\023\255\021\255\000\000\254\254\
\000\000\000\000\022\255\020\255\024\255\026\255\027\255\000\000\
\000\000\028\255\001\255\000\000\001\255\000\000\000\000\025\255\
\019\255\029\255\000\000\031\255\000\000\000\000\019\255\000\000"

let yyrindex = "\000\000\
\036\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\030\255\000\000\000\000\000\000\
\000\000\036\000\000\000\000\000\000\000\000\000\000\000\249\254\
\000\000\000\000\000\000\035\255\000\000\000\000\034\255\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\020\000\000\000\009\000\000\000\000\000\255\255\004\000\
\242\255\000\000"

let yytablesize = 51
let yytable = "\013\000\
\029\000\022\000\023\000\024\000\025\000\018\000\018\000\001\000\
\014\000\015\000\006\000\007\000\017\000\019\000\031\000\003\000\
\013\000\004\000\016\000\003\000\042\000\004\000\043\000\005\000\
\006\000\007\000\018\000\020\000\006\000\007\000\034\000\021\000\
\035\000\037\000\036\000\003\000\038\000\033\000\044\000\031\000\
\039\000\046\000\040\000\041\000\007\000\031\000\047\000\016\000\
\010\000\045\000\048\000"

let yycheck = "\001\000\
\015\000\001\001\002\001\003\001\004\001\013\001\014\001\001\000\
\012\001\012\001\010\001\011\001\000\000\015\001\016\000\001\001\
\018\000\003\001\016\001\001\001\035\000\003\001\037\000\009\001\
\010\001\011\001\016\001\015\001\010\001\011\001\008\001\016\001\
\012\001\014\001\013\001\000\000\013\001\018\000\014\001\041\000\
\015\001\013\001\016\001\016\001\015\001\047\000\016\001\013\001\
\015\001\041\000\047\000"

let yynames_const = "\
  IF\000\
  THEN\000\
  ELSE\000\
  IMPLIES\000\
  QUERY\000\
  TRUE\000\
  FALSE\000\
  LPAREN\000\
  RPAREN\000\
  COMMA\000\
  DOT\000\
  WHITESPACE\000\
  EOF\000\
  "

let yynames_block = "\
  FUNCTION\000\
  CONSTANT\000\
  IDENTIFIER\000\
  VARIABLE\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'clauses) in
    Obj.repr(
# 14 "a4p.mly"
                ( Program(_1) )
# 140 "a4p.ml"
               : Mgu.program))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'clause) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'clauses) in
    Obj.repr(
# 17 "a4p.mly"
                              ( _1 :: _3 )
# 148 "a4p.ml"
               : 'clauses))
; (fun __caml_parser_env ->
    Obj.repr(
# 18 "a4p.mly"
                ( [] )
# 154 "a4p.ml"
               : 'clauses))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'body) in
    Obj.repr(
# 21 "a4p.mly"
                              ( Query("query", _3) )
# 161 "a4p.ml"
               : 'clause))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'fact) in
    Obj.repr(
# 22 "a4p.mly"
             ( _1 )
# 168 "a4p.ml"
               : 'clause))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'rule) in
    Obj.repr(
# 23 "a4p.mly"
             ( _1 )
# 175 "a4p.ml"
               : 'clause))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'atomic_formula) in
    Obj.repr(
# 26 "a4p.mly"
                   ( Fact(_1) )
# 182 "a4p.ml"
               : 'fact))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'atomic_formula) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'body) in
    Obj.repr(
# 29 "a4p.mly"
                                                      ( Rule(_1, _5) )
# 190 "a4p.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'atomic_formulas) in
    Obj.repr(
# 32 "a4p.mly"
                    ( _1 )
# 197 "a4p.ml"
               : 'body))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'atomic_formula) in
    Obj.repr(
# 35 "a4p.mly"
                   ( [_1] )
# 204 "a4p.ml"
               : 'atomic_formulas))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'atomic_formula) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'atomic_formulas) in
    Obj.repr(
# 36 "a4p.mly"
                                                               ( _1 :: _5 )
# 212 "a4p.ml"
               : 'atomic_formulas))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'terms) in
    Obj.repr(
# 39 "a4p.mly"
                                   ( Predicate(_1, _3) )
# 220 "a4p.ml"
               : 'atomic_formula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'terms) in
    Obj.repr(
# 40 "a4p.mly"
                                 ( Function(_1, _3) )
# 228 "a4p.ml"
               : 'atomic_formula))
; (fun __caml_parser_env ->
    Obj.repr(
# 41 "a4p.mly"
         ( Bool2 true )
# 234 "a4p.ml"
               : 'atomic_formula))
; (fun __caml_parser_env ->
    Obj.repr(
# 42 "a4p.mly"
          ( Bool2 false )
# 240 "a4p.ml"
               : 'atomic_formula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 45 "a4p.mly"
         ( [_1] )
# 247 "a4p.ml"
               : 'terms))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'terms) in
    Obj.repr(
# 46 "a4p.mly"
                     ( _1 :: _3 )
# 255 "a4p.ml"
               : 'terms))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 49 "a4p.mly"
               ( Id(_1) )
# 262 "a4p.ml"
               : 'term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 50 "a4p.mly"
             (Var(_1))
# 269 "a4p.ml"
               : 'term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 51 "a4p.mly"
             ( Const(_1) )
# 276 "a4p.ml"
               : 'term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'terms) in
    Obj.repr(
# 52 "a4p.mly"
                                 ( Function(_1, _3) )
# 284 "a4p.ml"
               : 'term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'atomic_formula) in
    Obj.repr(
# 53 "a4p.mly"
                   ( Atom(_1) )
# 291 "a4p.ml"
               : 'term))
(* Entry program *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let program (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Mgu.program)
