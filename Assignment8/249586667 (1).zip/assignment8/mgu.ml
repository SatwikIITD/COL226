type term =
  | Var of string
  | Const of string
  | Function of string * term list
  | Atom of atomic_formula
  | Id of string  
  | Bool of bool

and atomic_formula =
  | Predicate of string * term list
  | Function of string * term list
  | Bool2 of bool

type clause =
  | Query of string * atomic_formula list
  | Fact of atomic_formula
  | Rule of atomic_formula * atomic_formula list

type program = Program of clause list

type substitution = (string * term) list

let id_sub: substitution = []

let rec helper_subs table x = match table with
  | [] -> None
  | (a, b)::rest ->
      if a = x then Some (a, b)
      else helper_subs rest x

and string_of_term = function
| Var x -> Printf.sprintf "Var(%s)" x
| Const x -> Printf.sprintf "Const(%s)" x
| Function (f, args) -> Printf.sprintf "Function(%s, [%s])" f (String.concat ", " (List.map string_of_term args))
| Atom (Predicate (p, args)) -> Printf.sprintf "Predicate(%s, [%s])" p (String.concat ", " (List.map string_of_term args))
| Id id -> Printf.sprintf "Id(%s)" id
| Bool b -> Printf.sprintf "Bool(%b)" b
;;

let rec eval exp = Printf.printf "start evaluating\n"; match exp with
  | Function("add", [Const a; Const b]) ->
      Printf.printf "Evaluating addition: %s + %s\n" a b;
      Const (string_of_int (int_of_string a + int_of_string b))
  | Function("subtract", [Const a; Const b]) ->
      Printf.printf "Evaluating subtraction: %s - %s\n" a b;
      Const (string_of_int (int_of_string a - int_of_string b))
  | Function("mul", [Const a; Const b]) ->
      Printf.printf "Evaluating multiplication: %s * %s\n" a b;
      Const (string_of_int (int_of_string a * int_of_string b))
  | Function("divide", [Const a; Const b]) when b <> "0" ->
      Printf.printf "Evaluating division: %s / %s\n" a b;
      Const (string_of_int (int_of_string a / int_of_string b))
  | Function("lesser", [Const a; Const b]) ->
      Printf.printf "Evaluating lesser: %s < %s\n" a b;
      Bool (int_of_string a < int_of_string b)
  | Function("greater", [Const a; Const b]) ->
      Printf.printf "Evaluating greater: %s > %s\n" a b;
      Bool (int_of_string a > int_of_string b)
  | Function("and", [Bool a; Bool b]) ->
      Printf.printf "Evaluating and: %s && %s\n" (string_of_bool a) (string_of_bool b);
      Bool (a && b)
  | Function("or", [Bool a; Bool b]) ->
      Printf.printf "Evaluating or: %s || %s\n" (string_of_bool a) (string_of_bool b);
      Bool (a || b)
  | Function("not", [Bool a]) ->
      Printf.printf "Evaluating not: !%s\n" (string_of_bool a);
      Bool (not a)
  | Function(head, body) ->
      Printf.printf "Evaluating function: %s with args\n" head;
      let result = Function(head, List.map eval body) in result
  | other -> other

let rec eval2 exp = 
  Printf.printf "start evaluating\n";
  match exp with
  | Function("greater", [Const a; Const b]) ->
      Printf.printf "Evaluating greater: %s > %s\n" a b;
      Bool2 (int_of_string a > int_of_string b)
  | Function("lesser", [Const a; Const b]) ->
      Printf.printf "Evaluating lesser: %s < %s\n" a b;
      Bool2 (int_of_string a < int_of_string b)
  | Function("and", [Const a; Const b]) ->
      Printf.printf "Evaluating and: %s && %s\n" a b;
      Bool2 ((bool_of_string a) && (bool_of_string b))
  | Function("or", [Const a; Const b]) ->
      Printf.printf "Evaluating or: %s || %s\n" a b;
      Bool2 ((bool_of_string a) || (bool_of_string b))
  | Function("not", [Const a]) ->
      Printf.printf "Evaluating not: !%s\n" a;
      Bool2 (not (bool_of_string a))
  | Function(func, args) ->  
      let is_all_const = List.for_all (function Const _ -> true | _ -> false) args in
      if is_all_const then
        eval2 (Function(func, args)) 
      else
        let eargs = List.map eval args in 
        Function(func, eargs)  
  | _ -> failwith "Unsupported operation or incorrect arguments"
;;
  

let rec subs table t =
  match t with
  | Var x ->
      (match helper_subs table x with
      | None -> 
          Printf.printf "No substitution found for: %s\n" x;
          Var x
      | Some (_, b) -> 
          Printf.printf "Substituting variable: %s with %s\n" x (string_of_term b);
          subs table b)
  | Const c -> 
      Printf.printf "Constant, no substitution needed: %s\n" c;
      Const c
  | Function(head, body) ->
      Printf.printf "Applying substitution to function: fuck%s\n" head;
      let f = Function(head,List.map (subs table) body) in
      let result = eval (Function(head, List.map (subs table) body)) in
      Printf.printf "Result of function evaluation: %s\n" (string_of_term result);
      result
  | Atom(Predicate(p, args)) ->
      Printf.printf "Applying substitution to predicate: %s\n" p;
      Atom(Predicate(p, List.map (subs table) args))
  | Id id -> 
      Printf.printf "ID, no substitution needed: %s\n" id;
      Id id
  | Bool b -> 
      Printf.printf "Boolean, no substitution needed: %b\n" b;
      Bool b
  | Atom(Function(p,args)) -> let result = eval (Function(p,List.map (subs table) args)) in result
;;

let compose_subst (s2: substitution) (s1: substitution): substitution =
  Printf.printf "Composing substitutions\n";
  let applied_s2 = List.map (fun (var, term) -> (var, subs s1 term)) s2 in
  let extended_s1 = List.filter (fun (var, _) -> not (List.exists (fun (v, _) -> v = var) s2)) s1 in
  applied_s2 @ extended_s1

let rec occurs_check var = function
  | Var y ->
      Printf.printf "Checking occurrence of %s in Var(%s)\n" var y;
      var = y
  | Const _ -> false
  | Function(_, args) ->
      Printf.printf "Checking occurrence in Function with args\n";
      List.exists (occurs_check var) args
  | Atom(Predicate(_, args)) ->
      Printf.printf "Checking occurrence in Atom(Predicate) with args\n";
      List.exists (occurs_check var) args
  | Atom(Function(_, args)) ->
      Printf.printf "Checking occurrence in Atom(Function) with args\n";
      List.exists (occurs_check var) args
  | Id _ -> false
  | Bool _ -> false  (* Booleans do not contain variables, so return false *)
;;

let rec mgu t1 t2 = 
  let t1 = eval t1 in
  let t2 = eval t2 in
  Printf.printf "Attempting MGU between %s and %s\n" (string_of_term t1) (string_of_term t2);
  match (t1, t2) with
  | Var x, Var y when x = y -> Some id_sub
  | Var x, _ -> if occurs_check x t2 then None else Some [(x, t2)]
  | _, Var x -> if occurs_check x t1 then None else Some [(x, t1)]
  | Const c1, Const c2 when c1 = c2 -> Some id_sub
  | Function(f1, args1), Function(f2, args2) when f1 = f2 -> helper_mgu args1 args2 []
  | Atom(Predicate(p1, args1)), Atom(Predicate(p2, args2)) when p1 = p2 -> helper_mgu args1 args2 []
  | Atom(Function(f1, args1)), Atom(Function(f2, args2)) when f1 = f2 ->
      Printf.printf "Handling Atom(Function(%s, _)) matching\n" f1;
      helper_mgu args1 args2 []
  | Bool b1, Bool b2 when b1 = b2 -> Some id_sub
  | Id id1, Id id2 when id1 = id2 -> Some id_sub
  | _ -> 
      Printf.printf "No match found for types: %s and %s\n" (string_of_term t1) (string_of_term t2);
      None
and helper_mgu l1 l2 acc =
  match (l1, l2) with
  | [], [] -> Some acc
  | h1::t1, h2::t2 ->
      (match mgu h1 h2 with
        | Some subs -> helper_mgu t1 t2 (compose_subst acc subs)
        | None -> 
            Printf.printf "Failed MGU on lists: %s and %s\n" (string_of_term h1) (string_of_term h2);
            None)
  | _ -> 
      Printf.printf "Mismatch in list sizes for MGU.\n";
      None
;;
  
